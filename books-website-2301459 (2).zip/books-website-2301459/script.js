let books = [
    {
        id: 1,
        title: "Book One",
        author: "Saimon",
        image: "images/book1.png.png"
    },
    {
        id: 2,
        title: "Book Two",
        author: "Jask",
        image: "images/books2.png"
    },
    {
        id: 3,
        title: "Book Three",
        author: "Imran",
        image: "images/books5.png"
    },
    {
        id: 4,
        title: "Book Four",
        author: "Tanvir Khan",
        image: "images/books5.png"
    }
];

function loadBooks() {
    let container = document.getElementById("book-list");
    container.innerHTML = "";

    books.forEach(book => {
        container.innerHTML += `
            <div class="book-card">
                <img src="${book.image}" alt="${book.title}">
                <h2>${book.title}</h2>
                <p>${book.author}</p>

                <a href="update.html?id=${book.id}">
                    <button class="update-btn">Update</button>
                </a>

                <button onclick="deleteBook(${book.id})" class="delete-btn">Delete</button>
            </div>
        `;
    });
}

function deleteBook(id) {
    books = books.filter(book => book.id !== id);
    loadBooks();
}

window.onload = loadBooks;